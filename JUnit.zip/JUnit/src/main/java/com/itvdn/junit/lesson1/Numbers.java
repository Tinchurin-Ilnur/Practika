package com.itvdn.junit.lesson1;

public class Numbers {

    public int sum(int numbers){
        int result = 0;
        for (int i = 0; i <= numbers; i++) {
            result +=i;
        }
        return result;
    }
}
